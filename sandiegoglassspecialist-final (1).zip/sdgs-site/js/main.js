(function(){
 const nav=document.querySelector('.site-nav');
 const onScroll=()=>nav&&nav.classList.toggle('scrolled',window.scrollY>40);
 window.addEventListener('scroll',onScroll,{passive:true}); onScroll();
 document.querySelectorAll('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{const el=document.querySelector(a.getAttribute('href'));if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth'});}}));
 const obs=new IntersectionObserver(entries=>entries.forEach(x=>x.isIntersecting&&x.target.classList.add('in')),{threshold:.12}); document.querySelectorAll('.reveal').forEach(x=>obs.observe(x));
 const menu=document.querySelector('.menu-btn'), links=document.querySelector('.nav-links'); if(menu&&links){menu.addEventListener('click',()=>links.classList.toggle('open'));}
})();
