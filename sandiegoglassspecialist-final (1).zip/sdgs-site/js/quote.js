(function(){
 const form=document.getElementById('quoteForm'); if(!form)return;
 const input=document.getElementById('photos'), previews=document.getElementById('previews'), success=document.getElementById('success'), formBody=document.getElementById('formBody'), status=document.getElementById('formStatus');
 let files=[];
 document.getElementById('addPhotos').addEventListener('click',()=>input.click());
 input.addEventListener('change',()=>{files=[...files,...input.files].slice(0,8);render();});
 function render(){previews.innerHTML='';files.forEach((file,i)=>{const url=URL.createObjectURL(file);const box=document.createElement('div');box.className='preview';box.innerHTML=`<img src="${url}" alt="Project photo preview"><button type="button" aria-label="Remove photo">×</button>`;box.querySelector('button').onclick=()=>{files.splice(i,1);render()};previews.appendChild(box)});}
 form.addEventListener('submit',async e=>{e.preventDefault();status.textContent='';const data=new FormData(form);files.forEach(f=>data.append('projectPhotos[]',f)); if(data.get('website'))return; const btn=form.querySelector('button[type="submit"]');btn.disabled=true;btn.textContent='SENDING…';
  try{if(window.SITE_CONFIG&&window.SITE_CONFIG.formEndpoint){const res=await fetch(window.SITE_CONFIG.formEndpoint,{method:'POST',body:data,headers:{Accept:'application/json'}});if(!res.ok)throw new Error('Request failed');}
   else{await new Promise(r=>setTimeout(r,650));}
   formBody.classList.add('form-hidden');success.classList.add('show');window.scrollTo({top:success.parentElement.offsetTop-120,behavior:'smooth'});
  }catch(err){status.textContent='We could not send your request. Please try again or call us directly.';btn.disabled=false;btn.textContent='REQUEST A QUOTE';}
 });
})();
